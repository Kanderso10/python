# Personal Budget Tracker

#### Video Demo: <Paste Your YouTube Video URL Here>

#### Description:

The Personal Budget Tracker is a Python application designed to help users manage their personal finances. The purpose of the project is to provide a simple way to record income and expenses, review transaction history, search spending categories, and calculate an overall account balance. The application uses a menu-driven interface that allows users to select different actions from the terminal.

The main file in this project is TermProject.py. This file contains all of the program logic and includes a main function along with several additional functions. The create_file function creates a CSV file if one does not already exist. The add_transaction function allows the user to enter financial information and save it to the file. The view_transactions function displays all recorded transactions. The show_summary function calculates total income, total expenses, and the remaining balance. The search_by_category function allows the user to locate transactions within a specific category.

The requirements.txt file is included because it is required by the project instructions. Since this project only uses built-in Python libraries such as csv and os, there are no additional packages that need to be installed. Therefore, the requirements.txt file remains empty.

When the program runs for the first time, it automatically creates a transactions.csv file. This file stores all user-entered transaction data. Using a CSV file provides a simple form of persistent storage so that information is not lost when the program closes. This approach was selected because it is easy to understand and does not require advanced database knowledge.

One of the most important design decisions was separating the application into multiple functions. This improves readability, organization, and maintainability. If new features are added in the future, such as deleting transactions, editing records, generating charts, or exporting reports, they can be added without significantly changing the existing code structure.

Another design decision was using a text-based menu. A menu-driven interface makes the application easier for users to understand because all available options are displayed clearly. This reduces confusion and allows users to interact with the program without needing to memorize commands.

This project demonstrates several important programming concepts including functions, loops, conditional statements, file handling, user input validation, and data processing. The while loop keeps the application running until the user chooses to exit. Conditional statements determine which operation should be performed based on the user's menu selection. File handling is used to save and retrieve financial information from the CSV file.

Overall, this project provides a practical solution for personal budgeting while meeting all course requirements. It is more complex than a typical lab assignment because it combines multiple functions, persistent storage, data analysis, and user interaction into a complete application.
